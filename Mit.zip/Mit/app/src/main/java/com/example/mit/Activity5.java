package com.example.mit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity5 extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    EditText et1,et2,et3,etid;
    Button btn1,btn2,btn3,btn4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);
        databaseHelper= new DatabaseHelper(this);
        Intent intent = getIntent();

        String text = intent.getStringExtra(Activity4.EXTRA_TEXT);
        et1=findViewById(R.id.stname);
        et1.setText(text);

        double number = intent.getDoubleExtra(Activity4.EXTRA_NUMBER,0);
        et2=findViewById(R.id.percentage);
        et2.setText(""+number);

        String text1 = intent.getStringExtra(Activity4.EXTRA_TEXT1);
        et3=findViewById(R.id.status);
        et3.setText(text1);


        etid=findViewById(R.id.et_id);


        btn1=findViewById(R.id.btn1);
        AddData();

        btn2=findViewById(R.id.btn2);
        viewall();

        btn3=findViewById(R.id.btn3);
        UpdateData();

        btn4=findViewById(R.id.btn4);
        delete();
    }
    public void UpdateData() {
        btn3.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isUpdate = databaseHelper.updateData(
                                etid.getText().toString(),
                                et1.getText().toString(),
                                et2.getText().toString(),
                                et3.getText().toString());
                        if(isUpdate == true)
                            Toast.makeText(Activity5.this,"Data Updated",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(Activity5.this,"Data not Updated",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }



    public void delete(){
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deletedRows = databaseHelper.deleteData(etid.getText().toString());
                if(deletedRows > 0)
                    Toast.makeText(Activity5.this,"Data Deleted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(Activity5.this,"Data not Deleted",Toast.LENGTH_LONG).show();

            }
        });

    }


    public void AddData(){
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean isInserted= databaseHelper.addData(
                        etid.getText().toString(),
                        et1.getText().toString(),
                        et2.getText().toString(),
                        et3.getText().toString());
                if(isInserted=true)
                    Toast.makeText(Activity5.this, "Data Inserted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(Activity5.this,"Data Not Inserted",Toast.LENGTH_LONG).show();


            }
        });
    }

    public void viewall(){
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res= databaseHelper.getData();
                if (res.getCount()==0){
                    showMessage("Error","No Data Found");
                    return;
                }
                StringBuffer buffer= new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("ID :"+ res.getString(0)+"\n" );
                    buffer.append("NAME :"+ res.getString(1)+"\n" );
                    buffer.append("PERCENTAGE :"+ res.getString(2)+"\n" );
                    buffer.append("STATUS :"+ res.getString(3)+"\n\n" );
                }
                showMessage("Data",buffer.toString());


            }
        });
    }

    public void showMessage(String title, String Message){
        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

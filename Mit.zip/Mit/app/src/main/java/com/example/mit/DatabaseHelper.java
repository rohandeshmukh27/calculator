package com.example.mit;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME= "student.db";
    public static final String TABLE_NAME= "student_table";
    public static final String COL_1= "ID";
    public static final String COL_2= "NAME";
    public static final String COL_3= "PERCENTAGE";
    public static final String COL_4= "STATUS";
    DatabaseHelper databaseHelper;




    public DatabaseHelper( Context context) {
        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY, NAME TEXT, PERCENTAGE REAL, STATUS TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addData(String id,String name, String percentage, String status ){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(COL_1,id);
        ContentValues.put(COL_2,name);
        ContentValues.put(COL_3,percentage);
        ContentValues.put(COL_4,status);
        long result= db.insert(TABLE_NAME,null,ContentValues);
        if (result==-1)
            return false;
        else return true;
    }

    public Cursor getData(){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor res= db.rawQuery(" SELECT * FROM "+ TABLE_NAME,null);
        return res;
    }

    public boolean updateData(String id,String name,String percentage,String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1,id);
        contentValues.put(COL_2,name);
        contentValues.put(COL_3,percentage);
        contentValues.put(COL_4,status);
        db.update(TABLE_NAME, contentValues, "ID = ?",new String[] { id });
        return true;
    }

    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "ID = ?",new String[] {id});
    }

    public boolean checkIfExists(String id) {
        SQLiteDatabase db= this.getReadableDatabase();
        String Query = "select ID from " + TABLE_NAME
                + " where ID=?";
        SQLiteDatabase dB = null;
        Cursor cursor = dB.rawQuery(Query,new String[] {id});
        if(cursor.getCount() > 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }







}


package com.example.mit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity2 extends AppCompatActivity {
    EditText etusername,etpassword;
    Button btsubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        etusername=findViewById(R.id.et_username);
        etpassword=findViewById(R.id.et_password);
        btsubmit=findViewById(R.id.bt_submit);

        btsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etusername.getText().toString().equals("admin")&&
                        etpassword.getText().toString().equals("admin")){
                    //AlertDialog.Builder builder= new AlertDialog.Builder(MainActivity.this);
                    //builder.setIcon(R.drawable.ic_check_circle_black_24dp);
                    //builder.setTitle("Login Successfull!!");
                    //AlertDialog alertDialog= builder.create();
                    //alertDialog.show();
                    Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_SHORT).show();
                    Intent intent= new Intent(getApplicationContext(), Activity3.class);
                    startActivity(intent);

                }
                else{
                    Toast.makeText(getApplicationContext(),"Invalid Username & Password",Toast.LENGTH_SHORT).show();
                }



            }
        });

    }
}

package com.example.mit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class Activity3 extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    Button btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        databaseHelper= new DatabaseHelper(this);
        btn1=findViewById(R.id.btn1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(), Activity4.class);
                startActivity(intent);

            }
        });
        btn2=findViewById(R.id.btn2);
        viewall();

    }

    public void viewall(){
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res= databaseHelper.getData();
                if (res.getCount()==0){
                    showMessage("Error","No Data Found");
                    return;
                }
                StringBuffer buffer= new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("ID :"+ res.getString(0)+"\n" );
                    buffer.append("NAME :"+ res.getString(1)+"\n" );
                    buffer.append("PERCENTAGE :"+ res.getString(2)+"\n" );
                    buffer.append("STATUS :"+ res.getString(3)+"\n\n" );
                }
                showMessage("Data",buffer.toString());


            }
        });
    }

    public void showMessage(String title, String Message){
        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}

package com.example.mit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity4 extends AppCompatActivity {
    public static final String EXTRA_TEXT = "com.example.application.example.EXTRA_TEXT";
    public static final String EXTRA_TEXT1 = "com.example.application.example.EXTRA_TEXT1";
    public static final String EXTRA_NUMBER = "com.example.application.example.EXTRA_NUMBER";
    EditText ed1,ed2,ed3,ed4,ed5,ed6;
    Button btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);
        ed1=findViewById(R.id.stname);
        ed2=findViewById(R.id.marks1);
        ed3=findViewById(R.id.marks2);
        ed4=findViewById(R.id.marks3);
        ed5=findViewById(R.id.marks4);
        ed6=findViewById(R.id.marks5);


        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();

            }
        });
    }
    public void openActivity2(){
        int m1,m2,m3,m4,m5,total;
        int sum=350;
        double perc;
        String per,text1="0";
        m1= Integer.parseInt(ed2.getText().toString());
        m2= Integer.parseInt(ed3.getText().toString());
        m3= Integer.parseInt(ed4.getText().toString());
        m4= Integer.parseInt(ed5.getText().toString());
        m5= Integer.parseInt(ed6.getText().toString());

        total=m1+m2+m3+m4+m5;
        Log.d(String.valueOf(total),"openActivity2: total successfull");
        perc= (total*100/350) ;
        per=String.valueOf(perc);
        Toast.makeText(getApplicationContext(),String.valueOf(perc),Toast.LENGTH_LONG);
        Log.d(String.valueOf(perc),"openActivity2: percentage successfull");
        ed1=findViewById(R.id.stname);
        String text= ed1.getText().toString();


        if((m1 >= 28) && (m2>=28) && (m3>=28) && (m4>=28) && (m5>=28))
        {
            Log.d(String.valueOf(text1),"openActivity2: Passed");
            text1="Passed";

        }

        else if(     m1>=28 && m2>=28 && m3>=28 && m4>=28 && m5<28 || m1>=28 && m2>=28 && m3>=28 && m4<28 && m5>=28 || m1>=28 && m2>=28 && m3<28 && m4>=28 && m5>=28 || m1>=28 && m2<28 && m3>=28 && m4>=28 && m5>=28 || m1<28 && m2>=28 && m3>=28 && m4>=28 && m5>=28
                ||    m1<28 && m2<28 && m3>=28 && m4>=28 && m5>=28 || m1<28 && m2>=28 && m3<28 && m4>=28 && m5>=28 || m1<28 && m2>=28 && m3>=28 && m4<28 && m5>=28 || m1<28 && m2>=28 && m3>=28 && m4>=28 && m5<28 || m1>=28 && m2<28 && m3<28 && m4>=28 && m5>=28 || m1>=28 && m2<28 && m3>=28 && m4<28 && m5>=28 || m1>=28 && m2<28 && m3>=28 && m4>=28 && m5<28 || m1>=28 && m2>=28 && m3<28 && m4<28 && m5>=28 || m1>=28 && m2>=28 && m3<28 && m4>=28 && m5<28  || m1>=28 && m2>=28 && m3>=28 && m4<28 && m5<28
                ||    m1<28 && m2<28 && m3<28 && m4>=28 && m5>=28 || m1<28 && m2<28 && m3>=28 && m4<28 && m5>=28 || m1<28 && m2<28 && m3>=28 && m4>=28 && m5<28 || m1<28 && m2>=28 && m3<28 && m4<28 && m5>=28 || m1<28 && m2>=28 && m3<28 && m4>=28 && m5<28 || m1<28 && m2>=28 && m3>=28 && m4<28 && m5<28 || m1>=28 && m2<28 && m3<28 && m4<28 && m5>=28 || m1>=28 && m2<28 && m3<28 && m4>=28 && m5<28 || m1>=28 && m2<28 && m3>=28 && m4<28 && m5<28  || m1>=28 && m2>=28 && m3<28 && m4<28 && m5<28
        )
        {
            Log.d(String.valueOf(text1),"openActivity2: ATKT");
            text1="ATKT";
        }


        else{
            Log.d(String.valueOf(text1),"openActivity2: Failed");
            text1="Failed";
        }

        Intent intent= new Intent(this, Activity5.class);
        intent.putExtra(EXTRA_TEXT, text);
        intent.putExtra(EXTRA_NUMBER, perc);
        intent.putExtra(EXTRA_TEXT1, text1);
        startActivity(intent);

    }

    public void clear(){
        ed1.setText("");
        ed2.setText("");
        ed3.setText("");
        ed4.setText("");
        ed5.setText("");
        ed6.setText("");
        ed1.requestFocus();

    }
}
